#include<stdio.h>
#include<unistd.h>

#include<fcntl.h>
#include<errno.h>
int main()
{
	uid_t ruid, euid,suid;
	gid_t rgid,egid,sgid;
	getresuid(&ruid,&euid,&suid);
	printf("My real user id is : %ld\n",(long)ruid);
	printf("My effective user id is : %ld\n",(long)euid);
	printf("My saved set-user id is : %ld\n",(long)suid);
getresgid(&rgid,&egid,&sgid);
printf("My real group id is : %ld\n",(long)rgid);
printf("My effective group id is : %ld\n",(long)egid);
printf("My saved-set group id is : %ld\n",(long)sgid);

int fd=open("t11.c",O_WRONLY);
if(fd==-1)
{
perror("error");
}
return 0;
}


/*getresuid():

	getresuid() returns the real UID, the effective UID,
	and the saved set-user-ID of the calling process, in the arguments 
	ruid, euid, and suid, respectively. 
getresgid();
	getresgid() performs the analogous task for the process's group IDs.*/ 


