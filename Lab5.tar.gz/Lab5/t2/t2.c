#include<stdio.h>
#include<unistd.h>

#include<fcntl.h>
#include<errno.h>
int main()
{
	uid_t ruid, euid,suid;
	gid_t rgid,egid,sgid;
	getresuid(&ruid,&euid,&suid);
	printf("My real user id is : %ld\n",(long)ruid);
	printf("My effective user id is : %ld\n",(long)euid);
	printf("My saved set-user id is : %ld\n",(long)suid);

getresgid(&rgid,&egid,&sgid);
printf("My real group id is : %ld\n",(long)rgid);
printf("My effective group id is : %ld\n",(long)egid);
printf("My saved-set group id is : %ld\n",(long)sgid);
int rv=setuid(501);
if(rv!=-1)
{	getresuid(&ruid,&euid,&suid);
	printf("\n\n After setuid(501) the ids are :\n");
	printf("My real user id is : %ld\n",(long) ruid);
	printf("My effective user id is : %ld\n",(long)euid);
	printf("My saved set-user id is : %ld\n",(long)suid);

getresgid(&rgid,&egid,&sgid);
printf("My real group id is : %ld\n",(long)rgid);
printf("My effective group id is : %ld\n",(long)egid);
printf("My saved-set group id is : %ld\n",(long)sgid);

	
}
else
printf("Error in setting ID\n");


return 0;
}


//When we run this program as a normal user it gives error on setting ids and
//if we run it as a root it changes all the ids given because effective id can only be contained
//in real or save id.
	
