#include<stdio.h>
#include<unistd.h>

int main()
{
	int cpid=-1;
	cpid=fork();
	if(cpid==-1)
{
	printf("Fork failed\n");
	exit(1);

}

if(cpid==0)
{
	printf("Hello i am chid.\nMy PID is  :%ld\n",(long)getpid());
	printf("My PPID is  :%ld\n",(long)getppid());
}
else
{
	wait(cpid);
	printf("Hello i am Parent.\nMy PID is  :%ld\n",(long)getpid());
	printf("My PPID is  :%ld\n",(long)getppid());
}
return 0;
}

/* If cpid which is obtained after fork is equal to 0 it means child is created else is parent. Failed at -1.
we wait for fork() so it will always run child before the parent.*/
