#include<stdio.h>
#include<unistd.h>
int main()
{
	printf("My real user id is : %ld\n",(long)getuid());
	printf("My effective user id is : %ld\n",(long)geteuid());
	printf("My real group  id is : %ld\n",(long)getgid());
	printf("My effective group id is : %ld\n",(long)getegid());


return 0;
}

/*REAL USER ID:
	Real user id is who you really are (the one who owns the process),

EFFECTIVE USER ID:
	The effective user id is what the operating system looks at to make a decision whether or not you are allowed to do something (most of the time, there are some exceptions).

The distinction between a real and an effective user id is made because you may have the need to temporarily take another user's identity (most of the time, that would be root, but it could be any user). If you only had one user id, then there would be no way of changing back to your original user id afterwards (other than taking your word for granted, and in case you are root, using root's privileges to change to any user).

Same is the case  with REAL AND EFFECTIVE GROUP IDs.*/


